
export interface VoiceOption {
  value: string;
  label: string;
  previewText: string;
}

export interface StyleOption {
    value: string;
    label: string;
}
